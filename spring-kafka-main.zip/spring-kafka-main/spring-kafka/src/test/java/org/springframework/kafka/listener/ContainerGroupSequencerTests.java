/*
 * Copyright 2021-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.kafka.listener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.logging.LogFactory;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.core.log.LogAccessor;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.event.ContainerStoppedEvent;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.condition.LogLevels;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.kafka.test.utils.KafkaTestUtils;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author Gary Russell
 * @since 2.7.3
 *
 */
@SpringJUnitConfig
@EmbeddedKafka(topics = "ContainerGroupSequencerTests")
public class ContainerGroupSequencerTests {

	private static final LogAccessor LOGGER = new LogAccessor(LogFactory.getLog(ContainerGroupSequencerTests.class));

	@Test
	@LogLevels(classes = { ContainerGroupSequencerTests.class, ContainerGroupSequencer.class }, level = "DEBUG")
	void sequenceCompletes(@Autowired Config config, @Autowired KafkaTemplate<Integer, String> template,
			@Autowired ContainerGroupSequencer sequencer)
			throws InterruptedException, ExecutionException, TimeoutException {

		// Publish before the first group starts. The sequencer stops a group once it is
		// idle, and 'checkIdle()' runs from container start rather than from assignment,
		// so a slow group join would let g1 be stopped before it ever polled the record;
		// g2 would then be the only group to see it and the order assertions below would
		// be comparing the wrong receipts.
		template.send("ContainerGroupSequencerTests", "test").get(30, TimeUnit.SECONDS);
		sequencer.start();
		assertThat(config.stopped.await(60, TimeUnit.SECONDS))
				.as("stopped latch still has a count of %d", config.stopped.getCount())
				.isTrue();
		List<String> order = config.order;
		String expected = order.get(0);
		assertThat(expected)
				.as("out of order %s", expected)
				.isIn("one", "two");
		expected = order.get(1);
		assertThat(expected)
				.as("out of order %s", expected)
				.isIn("one", "two");
		expected = order.get(2);
		assertThat(expected)
				.as("out of order %s", expected)
				.isIn("three", "four");
		expected = order.get(3);
		assertThat(expected)
				.as("out of order %s", expected)
				.isIn("three", "four");
		assertThat(config.receivedAt.get(3) - config.receivedAt.get(0)).isGreaterThanOrEqualTo(1000);
	}

	@Configuration
	@EnableKafka
	public static class Config {

		final CountDownLatch stopped = new CountDownLatch(12); // 8 children, 4 parents

		final List<String> order = Collections.synchronizedList(new ArrayList<>());

		final List<Long> receivedAt = Collections.synchronizedList(new ArrayList<>());

		@KafkaListener(id = "one", topics = "ContainerGroupSequencerTests", containerGroup = "g1", concurrency = "2")
		public void listen1(String in) {
			LOGGER.debug(in);
			this.order.add("one");
			this.receivedAt.add(System.currentTimeMillis());
		}

		@KafkaListener(id = "two", topics = "ContainerGroupSequencerTests", containerGroup = "g1", concurrency = "2")
		public void listen2(String in) {
			LOGGER.debug(in);
			this.order.add("two");
			this.receivedAt.add(System.currentTimeMillis());
		}

		@KafkaListener(id = "three", topics = "ContainerGroupSequencerTests", containerGroup = "g2", concurrency = "2")
		public void listen3(String in) {
			LOGGER.debug(in);
			this.order.add("three");
			this.receivedAt.add(System.currentTimeMillis());
		}

		@KafkaListener(id = "four", topics = "ContainerGroupSequencerTests", containerGroup = "g2", concurrency = "2")
		public void listen4(String in) {
			LOGGER.debug(in);
			this.order.add("four");
			this.receivedAt.add(System.currentTimeMillis());
		}

		@EventListener
		public void stopped(ContainerStoppedEvent event) {
			LOGGER.debug(() -> event.toString());
			this.stopped.countDown();
		}

		@Bean
		ContainerGroupSequencer sequencer(KafkaListenerEndpointRegistry registry) {
			// Before any data arrives the interval is multiplied by
			// 'idleBeforeDataMultiplier' (5.0), so each group has 7.5s to join and poll
			// the record before the sequencer considers it idle and moves on.
			ContainerGroupSequencer sequencer = new ContainerGroupSequencer(registry, 1500, "g1", "g2");
			sequencer.setStopLastGroupWhenIdle(true);
			sequencer.setAutoStartup(false);
			return sequencer;
		}

		@Bean
		ProducerFactory<Integer, String> pf(EmbeddedKafkaBroker broker) {
			return new DefaultKafkaProducerFactory<>(KafkaTestUtils.producerProps(broker));
		}

		@Bean
		KafkaTemplate<Integer, String> template(ProducerFactory<Integer, String> pf) {
			return new KafkaTemplate<>(pf);
		}

		@Bean
		ConsumerFactory<Integer, String> cf(EmbeddedKafkaBroker broker) {
			return new DefaultKafkaConsumerFactory<>(KafkaTestUtils.consumerProps(broker, "", false));
		}

		@Bean
		ConcurrentKafkaListenerContainerFactory<Integer, String> kafkaListenerContainerFactory(
				ConsumerFactory<Integer, String> cf) {

			ConcurrentKafkaListenerContainerFactory<Integer, String> factory =
					new ConcurrentKafkaListenerContainerFactory<>();
			factory.setConsumerFactory(cf);
			factory.getContainerProperties().setPollTimeout(200);
			return factory;
		}

	}

}
